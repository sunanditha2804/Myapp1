import React from 'react'
import Profile from './Profile'

const Dashboard = () => {
  return (
    <div>Dashboard
    </div>
  )
}

export default Dashboard