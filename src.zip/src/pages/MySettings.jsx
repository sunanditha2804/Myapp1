import React from 'react'

const MySettings = () => {
  return (
    <div>MySettings</div>
  )
}

export default MySettings