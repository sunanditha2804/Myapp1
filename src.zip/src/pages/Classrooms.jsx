import React from 'react'

const Classrooms = () => {
  return (
    <div>Classrooms</div>
  )
}

export default Classrooms